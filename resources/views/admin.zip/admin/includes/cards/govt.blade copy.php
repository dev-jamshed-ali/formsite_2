<div class="container">
    <div class="row ">
        <div class="col-md-6">

            <div class="col-md-12">
                <div class="card-client background-color-1 text-center">
                    <p class="name-client text-center">
                        Great work!
                        By Rewarding racial integration & punishing racial segregation
                        You have improved our Country’s Gini Coefficient
                    </p>
                    <p class="name-client text-center"> Federal Fraud
                        <span class="text-left">
                            Benefits Fraud
                        </span>
                        <span class="text-left">
                            SS Fraud
                        </span>
                        <span class="text-left">
                            Tax Fraud
                        </span>

                        <span class="text-left">
                            Fraud 0
                        </span>
                    </p>

                    <p class="name-client text-center"> State Fraud
                        <span class="text-left">
                            Benefits Fraud
                        </span>
                        <span class="text-left">
                            Insurance Fraud
                        </span>
                        <span class="text-left">
                            Tax Fraud
                        </span>

                        <span class="text-left">
                            Fraud 1
                        </span>
                    </p>

                    <p class="name-client text-center"> Local Fraud
                        <span class="text-left">
                            Real Property Title Fraud
                        </span>

                        <span class="text-left">
                            Fraud 2
                        </span>

                        <span class="text-left">
                            Fraud 3
                        </span>
                    </p>



                </div>
            </div>
        </div>
    </div>
</div>
