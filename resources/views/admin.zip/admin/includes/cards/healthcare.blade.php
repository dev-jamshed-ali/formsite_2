<div class="container">
    <div class="row ">
        <div class="col-md-6">

            <div class="col-md-12">
                <div class="card-client background-color-1 text-center">
                    <p class="name-client text-center">
                        Great work!
                        By Rewarding racial integration & punishing racial segregation
                        You have improved our Country’s Gini Coefficient
                        <span class="text-left"  style="margin-top: 1rem">
                            Personal Health Records Breach
                        </span>
                        <span class="text-left">
                            Private Medical Insurance Fraud
                        </span>
                        <span class="text-left">
                            Government Medical Insurance Fraud
                        </span>


                    </p>





                </div>
            </div>
        </div>
    </div>
</div>
